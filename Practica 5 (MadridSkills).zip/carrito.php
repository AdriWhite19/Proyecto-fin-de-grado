<?php

session_start();

if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {


    $Id = $_POST["Id"];

    $ListaCompra = [];

    array_push($ListaCompra, $Id);

    
    require("carrito.view.php");



} else {
    
}





?>