<?php


header('location: buscar.php');


?>